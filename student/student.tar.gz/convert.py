f0 = open('uw-cse-output-default.mln')
f1 = open('uw-cse.mln','w')
clauseStarted = False
for line in f0:
	if line.startswith('//') or not(line.strip()):
		continue
	if line.startswith('clauses'):
		clauseStarted = True
		continue
	if clauseStarted == False:
		f1.write(line)
		f1.write('\n')
	else:
		line = line.strip()
		l1 = line.split(' ',1)
		clause = l1[1].lstrip()
		f1.write('('+clause+')::'+l1[0]+'\n')
		f1.write('\n')
f0.close()
f1.close()
