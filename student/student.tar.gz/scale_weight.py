import math
f0 = open('student_9.cnf','r')
f1 = open('student_9_scale.cnf','w')
f1.write(f0.readline())
weights = []
rests = []
for line in f0:
	line = line.rstrip()
	[weight,rest] = line.split(' ',1)
	weights.append(int(weight))
	rests.append(rest)
limit = 10000	
maxWeight = float(abs(max(weights)))
print "maxWeight : ",maxWeight
for i in range(len(rests)):
	f1.write(str(int(round(weights[i]/maxWeight*limit)))+' '+rests[i]+'\n')

f0.close()
f1.close()
	

